"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'W8io$y9u01*<Q5L4m;OMZKb(a4DEc7rh;mIke*6vSOFGTMhC}<K7XrdGCxy`@SC?J&EXfGqPTh$sR9vgJ>%;9CTI|QEQWWZAceTANMI)XBZIU+cFFG%=<o3gVi|!&6CLjrtrDg3aU6;wa?Zl0DI@am<?T5$qO&#Ty##LYsd<cF)#LP)@4+*PC)$^hHd&oa7{4;a_ftV~NhH}O!D~d7Z^g`X%Wygm{)D_>(mviKLN0}kpNF#3B&K<DL1Mpwlfd<XOJNm@OzlZ{f1`X9(+w`zCN6Zu9i9r>5Y=+81hrIX&{_&e`Ss(xhTQq-HN=fl4%SHU13~2+=o#)SNBG+lXrv_|WkO6_m6FH;sT7zC{S~hZyf+>mqGC=Kgr5IgUfx)dVjs(&gLKJoyq#Vw%6Mnre=L?1JIKO3vXhJ@B;6d|v5!DOnXWPnkktiE_DcB8Wf!Sa{Nv8fh*@2FnB769PauIaB2;v$_p+vldt(|Yq4C>1QAOa29r=o-kc3+mJJcR&DkS8b5;KEdN~-9(?a&CsI2qw@?=hnOn8W0=_Xwfh)WT;PT*a@YWPX+;&vkSCjz}e`ubt7G5=xorfeR*$=N#I|+<ZxSZO3%IFyIFWUgiZ4?JUQ2{6fm*)31B(i*CYIr9{{q8}f0c!|}>+5Z^Z0UPzXbnF(1jp{9&v^6J&`zzue^d6C)Mk?pezRmxH;vFaV;wK!S&DKY;PO79AbvgiG&(!@1)-ie-f^qmbCf;i{($Gg8$p&!qQqAMRM2pF#iS*F^uJWaw#*PFqP<~DD7m2N%Y_8MK&X~MZxo$u4$AR0VBPo$g*nH(_^%BErE^aIrm)f6s&CS4-@2bFtt!4WQCG)-*LVMh>(Afo99jz|2GW@nB36WdWG>zJ|R6qDC*w8k%k8~oNR24=xGLiqfWd8n^ENSJ^qs@l8?bf}`CTdMlj1T2&==@nYJdX<{<w%2O;&BeuTZ}-+_Dj%Bzy=d}**HC%iw}&P!fa@qc?215|4CEF&+&XB~i?rF|wH(u^Tt#b%XMr%XDTQHi<c5c%ARDOfvrP_za5952O6FswM)gjYaaYw!rpZ;4eii3;b?>1ft5p=fS#{W{`%Z9CgSNCJ_Y{yxzT05^sI{mb<r6N`Fc3%B5IQ;_OZX5=0UEtU*Xp`YNaXSFbeD*{y2p3vZ{A@bt_=Sh(1r'
_HASH = '6db68fe46ce07c52877fa6c3d3a34ea0af2a53cc27908df214c873b021aaf81a'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
