from openfire.cli import main
main()
