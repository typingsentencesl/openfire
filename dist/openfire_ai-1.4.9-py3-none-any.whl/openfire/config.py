"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'vHM|8B-!xxu)L<Ek$n3_ti+#lyS~C3NeLsY%EZc_AGho7tp0=s?kuH3h@;JfHv|6cz73}UvSLdxPVreEWqLP|gxJ&m`tLGvB51S|Ez5fkevL!Gw7*b9<&^a7=|3WyT&}WhYARjP%S#N8+*gl7j@3q$*V%TelUOqUZ`fm1zfDIQQ2f{ToD<t?0?eE<z4@vh0R<-7lqPL^)JnOEvI=O*FKa6Aj#zaj^G#a-DSj8$i<Y~+0%lQxcW{P_@wPKfb^_^SsoVqA#R8EPMCx-<)F!RARY}}ASR5D1iXrSMltb7wi_AK-VmHi%Ca(mBQWe*bjG_3FLu7ySeI3{Qgo#J}Ma_TT(=mWI0AW}f?QG%MjP`-i6kEwlqplMFD(M_$iXBc8m3wEW^)vD=G7%SCDX}h^E=W_Sv+;hRZ$xq%YAzSxPDo=P+U|a3ti|)F{O8+&LCoImNb!`4v35hGmLa{fZTJhtk1?DK`f3y'
_HASH = '2ea7f9dcc8dd492bf74132a0e5da62a9a753209d33c60a5a5065a0e3f7019686'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
