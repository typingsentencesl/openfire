"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'r9sxp3p2DG`rQo$s5QS+EClM5uZ<IbR=4Re<C-_#psH%Z9n>t0GepRwyp%p|sV!*l$%XYtR1RLSYOMM98qv;tM?FyyP~PkL7}v#2Gp%MuLtT4TzC8DCYwgQXMD+Tz0q??_PIQzeI}KhJ;GjV^Hy@=|5d*jBP1I;Ha`g~}|4hI}3r}_b=|ase97tQ$NepNxyEcNh#=r?~9T3HPnyQ;Jn9Q@xR<J0h)-7YvK7nlcP!Xs8ukkJRI(HIP)JK~yEi#-6jhgjqV~uR?oxr^2jHHI54aq(<2o2%{7|s+TY#x+dF)yo>*v2)aCZeM-D&HPK{+20M>#&)I=_rO>X1fQ0!#u%K7r7mk()rhnQ$9hN08B3T;zVqV4mmKOyn8W4h>m3)SnAv|Mb;~Z#gJi9o%g#XqU?7oIgUz$oU>}43aOAU`jCd1!_n~Z;-eR<N`HE&^<J7u84;#q#I>5w;2(lRI<TYQRmeKo42@9Fi);yV0FR~3(e)DW>HyrROtqfCb)K(z@hd@a5gxQp^{d=|ovnr?uW%5-z!T86OIvjyd5bSn7v($gEW9&&o(W!NbkLxp7yWQ=s1NHWu>#B5yTcJiy{nl2uD#ShL5-v=z(kF+Ld1Zy+tJrYEnkXExE&iL!CGrizym4F0p@(#Mu&;?aj$nU5co=Awj2Y@{w+QhgMvw)K`CXpG^L}xf<@Oqa*9=thr;oZSxjh1wVy1+1L$Q{>#?=_e|iENRE4|z>ujMILBzVGi-gVZJvXPJ#7Np&mb3fP*Wsb2c&EelPIV>y>N!49pUm`nGdAGH8<!@3Nbb+mgx6#J#?*Lt1cr!fZ^E#~Mkm}}Z5%eRWWeefH}|)JAt=>xjUZK(i)>w``iWWu!yCxMDt8Z4<cs^SoA|jusM5=><UwH1Q0pNq(HpRVeBga<!K&zVwc@h{N1619|NAc$MB96&t~6K$Qt<Qxvap{0mGj$NxPriQx*qR_JK92%;@{$ba<|Q3U<eb_XLNnSHMkNTuYXeK^{i>VAdb=ZtkW5+5&hZBWg-~Y`U5_69rk2IrjFWyKbXzuk$$ww{((4Z8PnV3fHezT{uRO8bs%$Ty83K}22$Pr*R9q3r^R)Q_J;@6_wx>er>(-)*?Pw0gI;rV6ONXKb(n<@+)bX_y_x>d-FbA&A2^O8z@K;EhX{KwYf9eL8FeMeV1x'
_HASH = '6db68fe46ce07c52877fa6c3d3a34ea0af2a53cc27908df214c873b021aaf81a'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
