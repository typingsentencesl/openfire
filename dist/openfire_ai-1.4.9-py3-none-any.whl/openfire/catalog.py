"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 't0YRJ*$t%z|9xAK$I4s;j&vXCWMQoef1@(b>wi3GL^pN)73(JDMJhQX5N`TaXFBSOKxpwqjFjst&++OSM2##$8s*EnHpv^x9oBGb=H53-ur^Zm`qwh^y9eyu281ovqgoEOD(Sg&bhKn11KkQ;m|wz0n}q|wi9oG@<$^90wLmYXwK3uleIi%H+(0tiew7LY2GLY6F73&`|M)-?7~Q!3seRG`=`t;x8g(JGQS4`}FP!r9IsJ4%sb~XA3O8);XT%0rL2U0r?@LNvrD#w6{0^UHNO{%mY>E{22iJ$NaGgzv!$tweCGra98(oYuM%&p!QJyO?m+31O7w)9dw!JI~eREe)!PjpgUo9L%v0!i86ZV0e0{N&Y{*4x*;eX)E6OtUdcim!qj(iKw#;BaUvJ09hcmwr1_YH=<G+2(x*?;8uiVN0RzP#w*aX^6X><+5OsnT}k+COrNtoG$e$ye+I_*3U)HR9`=gbAQ?Lc^}PIWJQL0SP!Hf%^AsuXO>VD7|QiFrw`j19ekjcbZhV%c@14Z6042tw$Ir;Rs^}zg1DsSCl0SeICCDR<b%Tb~prIZ(b0H)n4|6Jp>))6Tv_ZOvtv>R%R<2*C#G3V25lVn&LTbN-PUJPyYt(g)@5(F200)A``5%R@tXhNMbm!bSjUPq=p?%1v-}`dG*!9NJ59`;uIR)gkp*3z6PiBnMQEIF_j>89$Kow;%5Hu2tdyTX9MjQ#*hDgEzo4J>;my?EsxLMB$lYA;7Mush2!JBSjR!T2c`BOY5%s|0ed)QX24+~c(dsweKJ586UF#0c8)XUSE2qqY6A_aYj-!%6_07BKUc-^xuiNU`y@xy==(#1dF|_v5vXChhh2UyF#JjOHc52-RBsZ}WGnt&mB13lE*653;ua5IPwDKSO?O>kAP|{KE+}kzjTn!iEt*&4Kyh5sfkus|kr6`-|AnYmU#)tJj+~gV&E<r$jZQY=K0pkvSkN5qho()lVQ_SAGJwGlBzk>hOv1A`P@%4?<tmOXMr%{=og3(-xNwpl91(4UmxC@N0wI5|z8pUi!cpS8O3p!g3>beZHRnL9MvPel(J!0E%{0iZS0O)i`0Qws%mSB<ypeSbtnk+w3MPP!vm>VS*@hU>8K0w3YI!|mnl0P87;O1{kl;l-+c(1Md3A77;;jOjBX4AX!CQR{iR<JSD=%o3YFL@jZ;b~d(kA2wFlffI3oMh?Leg{v9U_G7V=xg}=@(udIO({yaABm5pA)lhmt`9Yn_?Wv8pAQ}xc2lX)HnRg?sJ+B{}}MD1|yg7*+>Ie7i|o}fE1uuYk&I(tXQyT)*|xy?DE^mC0&$Nt_oJ$0p0=*F$7g`9QC|#fN<cx6FQEvTlk*G<Gj3)?-7d${kEbK>_Y~@Ql-fEs)t^=LbrD%yA92z0S$UpEiL9lIwK>U%22L#Q>kH5wpv=K6V|QihB#fCRA#aa;t0;pfQ5nFk-QA2<%?#3pB?!Ndke<!WL-gglJ4c%iM3Hn22N(_9MZZ2p_-3b*1D3%NSd9H3<<7XRhiHj*XTopF>c-5n9arw<sc-lT=@jV^}uBwA3nCJs4>kb1W~ituo~!I(rsUqNY4;%Jday`YCz-XoU&T6)&iPN_xaynh{W>u;joSAuQE`8-cNpLZF*LtF<Uv7;;?BK$0ThtwkqIST-$IjVD`+~ti{S*'
_HASH = 'a93e4f2f3952278834d0342bd7d48d291620f19e593b64299c3a52dfbcfdda1c'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
