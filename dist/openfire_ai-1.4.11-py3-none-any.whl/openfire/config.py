"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'R<QNN0a+-WzwBiBkhu{S#!OdxGRA1J20V1&_GI$VQmygaF*>nVQIDqVBH||$aITC|kaWgr)rRJww;BBm*8{}>(FYwIl*3^s!g*P(Uj3COjV(YtG_QDJ+7pWej4WPlAx<amtVTkiez=uVd&j446kgc#%y)9B5flpaB2}|TtCSox@gHKm;4-RX?+x{2&pHnfhY|0Y2t;@y=**0zdEUHYp^vr9f=sUe`g3waafSn_{056z)jTcs=pm_nWxHL&6%|`?wU)f3VRj5x^zT$uJSh'
_HASH = '48e42a3c85fdd7d19bfdbcd67e2ed26f86cb2ca9012466eb40ab4c7fc5dce3a2'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
