"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'V%ob*geTc#{d&f)Z}1bitUtR7Gbnhb9(F_RbuaG!t_E@*XQ6r<p<J&Ak+m*}u!XMt{|H5u6|7K{yL+Xj=ZZktWesZVxP|<jNKq1<nDQjv*zRa>-WrBZXhzFyy3F-oiB>_(pl;?}62)>1wyYrq&H3(YWlT+BnY{b^j}N8^puZZ+FZ+Jd-c9W5-(Nz0MF?k&oZk5eP3}tLwc1M$7O*^&eVaG!VF3FTm#pa7M)0N5K-1|QE!C}yHh;R%KE-Q!!|5pV4NBbDEqgghOkGgoSJK~XlKm1frS|oN<O#v?$_g#;!T!>??aX)h(31FYYsY6LwpkcBu@d3?iBecb+4?;Nui}=JC>fm}_B)U)LyZxuKlHI6AQ6my84!2Z%12(gV5u1Yq{WJ0r+!rzNj~a)L3W2+?lrZva0R4}-S?GtLnf=AAY-ccq*E@YGw8HgF^iU8y2zp1CZi8!&@u-4DhtAjm?*~w_ain4!yke'
_HASH = 'f9ada9f0f98d493749b9b814e17caa1f29efbc0346989d9faa318fe5bdb21fce'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
