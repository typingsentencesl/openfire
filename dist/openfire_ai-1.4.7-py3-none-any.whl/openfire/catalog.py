"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'jZ2k>CmSKuEcEqBmm&Gb?4J_*iB!8Xr+wS#+&@*Z{reiS8o`Q0#&-w#snp5?S3%-NMK6u2^wZEG8>M8db$zhAT``Ia9z1Vxw!fBrHFY)*xL9s0Y)p<m8Z9tAYWW#+W88n#?4wQEykAUlu!u!&<~AwG27)W_418h~ZFtt+?P;#EEk2TR<JBN5y*<%I)WF55;suVzSJEjg2bTEzP#NF%uk^^=M@<4%X@z16q~=!;+pTPc9heW(b^`qAJzhkbt1o^@BZz{GIb5zTa$bZy+n>fI*#TjI9|J!u?wpUsV?2LsAsTg9QYZ^lUf@6Zs<5$Lt;F%|3lXvU<UG8AM8dnTOz`_)O5q+l=X{=HBEel)pP?d4>AfovcPadSNnSJwH9u4Ikp5uy>|C_MgA#@n7;-0tt*t7MV0jp<R|V4wU16ls<!M*&f1|tNj=DZQA)7E}4PTnI5lTOiIB+!0<;|Bvhm!+MaP&i&T)+E2t+*Xvi>fg9<?weJ0GS6=TO1)_f0K-bMAz9qn?v)os))mZCT)$c68h_3g#m08boy+RxC$Chq@y_hCrdUHNZ~o-T#=47qlErf-%S<&{dcQ;(l&awNWNYVkxjS~@nCj}SbIg8N_WT~P+U9D%FCb9vsOW5I=MI1NCe`M<>R)-2@LsBxcMiq6d6c8xI(-N9Jk|EGp`8bAb4W!vNl<OuGu^W^Om<=B6uyU)R$z7XzX9BI0PbBdWi{22g&;&4ota47?Ax>Bl*?}g0r*OsnMXUy(SMK+*JA8-)~H|oz1i?t=Ys36kMI*=OpuJFYCBd{pZ>nf^9rEhoj0X=QKZ)g#8Ux){Iv~CkF}Ub{%_RT)`bjb@A!<aI2O)=Ao;+_bv`LTL0j6{SQA5isPBFG<-(T9#*-g&J#uqv851WIhNmv8!B~4?N!pQp_z&FI3-B^YWtVAZ1*T4ck>b+MbNK8g8}{EDlx}S>xzBaa7|XmaGXZomQD;S$j}n2cm~2b*vVgjHkMzJTI!8^0>(9c;9--0%Lv#nz}5xVxD}~NJFK}XYGGbk##Y~+gj)}UdBN8RKSrNDBVuWvosD5<9VV~VrEoTy1#a5S!8N?*dFGKzWIN|}3LUS#)O%icghC!TvOK8AQ@M!87f@Z4K)IojlX035;2P4K*#<4uEix$VaV!DXec@30Ubbwxr7HpMsls-zD99(Sjk9P_cZihF^(lx=PfhEqst59KQspXUmYMMCN%%Wl4SXs^L}d0fVtKe6(VCbQJe?DdR<J1}%dU9hnqpYCP9N<CzmAKV!oKiU<qtulJIjzj0Q%JMQXiVjR)`A=L82y!NkR($C{HMO-;7`Y4LoP(XbQw*h}4j}zJdlA!x#iYnql0~|ArtGQVc$@cNWeU*6mTEG$&N<_6r4xJn)T|ZSuiZjTeX~TD2Co2!`$>z$GS3(sZi`6VG&fIv^l^@nOkH1SQC-J`al!!pn#&)T@XXszm7@GP!DO0QN^^QRwm4Cm}dnTuJtEVW*qpjd%;cB_*2JLs0A7xtBg0;7KjZUOZ}cFc<2z%|T5u8UM=qw}oRFMj3mU#D0ITW!$5MS=eUc;@xE|fd=&&l$``>Wp5!0S%U)e$N`@fKVaj<9P)Y7)<x;SEz>vXtT8w0-eVJK&(MtNlR~iJa{G4xj(=(Ix|%Q7ve_d5L5laXcn8J)_g9vI6F0<bD0fxF'
_HASH = 'a93e4f2f3952278834d0342bd7d48d291620f19e593b64299c3a52dfbcfdda1c'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
