"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'yX9mdKVeefbdGavK*;O_!~MlQ`;bS-?<EWb^7-;cstI2#f~Vj|Ku8fs>qHqO<hMQ%Z&Gu{2hw8@A}+6H6f}l1LyM7+o`reytt6k?dclVn(;j3MOkBfVBkfkf0-%HyR1E2}9~2KeqWG#Mrc2U+oBu+c0o49m`Zi&|5oA>ATUVEQ>G!E<<6Z%mkH4|Wh$H1}TQ=B^Hs+Yu1KpvBdmtfPJ=F(|jdTop2%zJ&Qd<xnr)1N2w6ObJ{#ww=7bY~Q6_Ie)K2X>hCOa=pDA_Id5N*f);P7!M-NuJ(Y9mx|gRpGV7q~59={7@_e=aa5E`O-1dXx`|o#o(@rM{sH%^6;yR?<SK_uYG)z9<GmDfIA;ZGE25`x%mc8X2GrjMfGDmHAvG*3Ven|Cg}_#g1H>Yr)?%$9r@x!y=XjpD$%u9|(47<Q4IV)5Mf}${5-oz*xW5Ys6P{GcUN)N7bTeI!54CIt6kG$}K<cfHSWGsHKVdXiQ>ylJi@g0Sl~&U!K__SizFG`_%)N@|uyh1J*WJ0S;`V_(}nVMtzMc=qwjcXm{`xF>LUA#fgqMNLxv2LCfjfPE`Eun<V7JiPOBZfIXJzEcYMRMbgi5n;?+M^jXaRhz!ErHkJ|Ly&yE^jq47=8dmqs24xhgDgW#8ezu?xo(*a-kd{*-BUG&io?QVl_J@dU;S~;4nj6ZVHt*`F=ZOe-zgqY3JkKb(QdGd%NId}(r|MCPH1gBAL4Cp?3S)!;ps*?;HPtnYaCO2j{Zk7fT>l8hON5|F$@a$liNGW+dh-BPE*YY6+Hv*>I>Y>fh>{9{om#>ri^h{FVE+x}_FKC*s+oqpb@S#JQyXl4pNGz=4!UJeuz?1Md5jGIIE>4W!(3Hvw0av?8IntV!ilumm2Uveoo$E&xQZCx{luJd@o5p=mA>>E2HUjF$O^a|?;GgA5FVJ<F2as>zH7L*4>=!XAK%4%-h`>cOT5x&7)5rujd=H;66n=zdSf(m7Gg-7_^z3SDMaJFW}c?gf@`sDEM|AM``mwS(=EuX<jsEmZfVr4z;8_~Pef4~PV#jdnEZ`jGuliSjl~&{<V#*I`M0=6`D}p7(WwuQb-GCjOkr6zY#pDoU_|5pHTCDi9=s4>h$7g#0wBdi5+<_$?#X^++c`5Z%=RwiIsiGzjHnvc(k|5@<yl@R-pXwLE*QxnTzuGmHmocgM2@`?I;Qg;4GtaB4&B$c!J{C<SoP!&PepOko}Xal)hWI`U-o&}#eKOcsHji}RS6v=vOnL(=RQJhYgPKr=BC~8mxa^VTeKuK9n&n-60Gb)=Hx0a51YBp<QVS##P*Rou9Y+7w`t*cH?U>7+7;joDjR(hb?P;f2@mb;Y&91yQ^g}!_(OOS)yHq);7{OK=}&jw8%-fu8!x}m<h=0fW(mXjxq!&W!b-b!Of4h`9*t+@r(rGTlDV&gn_iWnJ7^Q(n1eycWbyZ2^ff3Ir)RebSZ(SLA4Eg>(henbT^%w2LJV);R>N51==v*JEBHZ!_ed4e0hVB%bM#OAzgRl3Vt*N<ewn)Ul#Bk&m?sp|kOl$@B{#gdDcY0|Y3<@v>(be?>r8rkJ)+Hf&`LAb*3y>;_xTY%l&WLn$KJg4J>u(C4pXpnVnTC-VC1+O_XDD|)?Kl_Fd8pf#y0P4BVrd>JmzplHW-%%#d6MJy34TU^(Ca2'
_HASH = 'a93e4f2f3952278834d0342bd7d48d291620f19e593b64299c3a52dfbcfdda1c'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
