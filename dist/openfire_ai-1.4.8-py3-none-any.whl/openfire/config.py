"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'm^ENca+-h19mkKan!GDN)#kH0eQpr<4#ivY)EtEPq~hN5Kb<-9w*3=`2Ra7A$hOWc+acBWrJ4Vnl%ps_r8{1e4lRC~^k8aCwZj_y&|^dMlta3As}l)NG_ECMZ)0k7bZ0YD-E@iK229?Y(Zn<@%x3ml?*}g$=O6n4ecE^dH{rmsmgq6{yRzDnL`FaSDxj!!Lj&UuJjMQhRI&NV2}}CyHT4bK^@Zxu4LtImz#_99*2smAriCJD5k(Efk#f6>Kf9wBBtn-^pc%y_6FuX@!H+_5r00}PyP$Xf>6aE_YYC4eM-S*$5Qbn{@?l*&<hX*o(l}ofd3e+{Skm^<4JDi|v`YL{Zi-%KBbPrCjJ^knqoc{S$mhbuzdk2%;p{Igvp1KBnn<*}VK_p|cR9h@GMDC?=DF>dWt9@9xrc0tuwC!SUt@KBFqx%puRmI+;|Em4O-NqwLG2fPZ$tDwVfM>Lj8~mgLFEkwqQe*'
_HASH = '216c11bdd2568f0f4cbcf68ddd49065e9c1991b11ae53efa69f7ad507c3d55bf'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
