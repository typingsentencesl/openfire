"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'Qf$Z%Z4^`}3(k~6z@FsV{<P$@U~=6@2(%8&b|D{hu!G{srwQD9a3Edtd?0ELQZG4K_5A*a<I`%OL+T;2QxzK8`DWRI`VK%1?Go`bgZ{y5M74Gq{o2q(5M&B)xrOtfAN6Z11=9B*p1&q?-=lbZbFKo$s^-IuAE!O+2tmQ#7CTD<>HV77l(tc~OG0^*6$)Lpt7@d8gc`p%a}gm#7HhIK-snq{6&1^FQX4aOxDJ#4m+X_a0e$t<pUGDFph}iL1UNW==Lt6rtA&a<QawL2=jEFw2fFSSeXrSACy4i|%eL7Z1XU7clsYD$s?bv<4;+Q~(iZ7|aUA;a5nwxV7ol@?96oY>zDcBIws4Zk+9t)q_PzqG4P}EF3iZ)L6v6Q5|6^_e&TF65cQT8VH~~?^Ky{DK&NZT0!Xpk`fZ*2eDaHJAyBY{*V2AuF%@)K!{7;pt=&N_m6bm4U097Dyso!Z7htqq=Da4ZF&JE1p'
_HASH = '793b15b8ed72362dd3434f6868e1389cd8c108e2c8b49fbd1c470c87e0bf216e'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
