"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = 'lOd2y<kt*Aqc9!HStQ_sDEOi*A*9Y0rSz8<=15k#6g&4R_}nOz<3OXy2^89u@Y`VK^9<|A7B`ja!3RdvExGO&vMp#C|HY-FV73{<^<Q<Y6Z`<jo>Q$P9?ImBa!+uR*9${2{6%B@=)to3C8!;TRk9ifG57zO{i-n3&ub=Ob5|X>X3s>vYM&X96tci`gD(P6vp;$HptgRHd!`yZAWAFkwc|gLsG=__0av~WKxOh+WtVnE`?#>7WITr0h%)j2HrzmLv7IS0x{qLG0Vu~RkCEzDNjY#rzKtU?G_U?%ri5i8>i~Bj4xnj0bKV4eFGNDq(IQk-mL&?wW67aZ*t88`5%?P+IW4h<yq;tRMh}%)a>7Y}G9G8|<B^Jp&@M*HS-Dt&<kf73Li!a7w41%01_XuW%Tl0GzgG=46kV>uc0-khvAsM;azoG-+^Iq`I=e0i(B_OWfxF9OH}8oEv?|>wF|r)I!FG4@rk?7^Ci3w3w*mWbj`S*gflKY0?(yuWIe+)h{7U5i$_!Rc<4D;FyqfBxC=vQ(pCc`rZ=Nz?psszNi#4{$5$ECONQEwRU5>i8aypY(jV*i5(p^(8t|r;kzaO?%Om#Q9!e>RApzu6JpXE0NBSN@iyfKpca(4U0h8O**wC!NZ{z^1QY`B=0^iDASq>ip@hmi@8i58J!aoAPCuO$28c;sK2yh-)uFK10sFotrYF9Q+V^A`-lM`{f{t&;8&m$;b`8mW}X6Dj!OBD;eYe8Jm8+;6Yh_PlFB8q|x>OJ}5AbTaCF)j>5(*<q+(Tv9JMU%Q-@p`^Q<;tpb`dw0Z<tFutL5#G!oz(+MP-tJm{Y9df5<O$_Cc~eQ$c2+_8>ft<Obnkq+iAOTWL&LQi(~>)sa9ClC<xIQdbYyhp%O;3=b?na*Ot<UsHxwI0@(aih+(zKc@78ir1g#P<%VxSbAWl`ulIp3v8>>-Ss)~XSnt^x>vT2^pMf{9Uhm{elzopEKe}5Y`zTL=wG=}%<T-r$a^L}BrK}djq!3N_7I4c}()wC_)>5X1*0pUDvLMCe|yzW%U!UST+;gL)SWq_az*p~U-Z=e9l&t0MT>t5&xK-YuE@y!&sAnS-nMy)gb;SLJ0fX7BR`sd!Oom|tXFxk>&{<Ya?CVyI}^}O$al2Xo91z^58Y>ZUzwoZjdKeRv{f=f8bFiFm`;V}d17CJMPpy~4jkL#>|27gN&)I^KP@jUnTqn#-QT^7xb6h`#}-e(a;B-BiGVeenj(Je-?@~Rlm4t8WO+5Cs0h(17^;PU0N)<Qmy^U^N&fMuyc@YD*7(8JDjC(0*k>{Tlnfzw%uL_s)JD?^)7!>PpTT?Z&95s0Dsi<!OGM^YOtjajj;Ks5ldlc33knYQ7(rinp9G*znI=Y8beOV7s%o6BQNh4jbm8&Z|6l-dPTnjt3q_DQq5cu$@Hm&?F3=R1s*i07RAct8ZLr3ojFTjIXgY6Kt)QqTCiUk472O7G}Qe?(_;CGOrM?6=qfxBu9=SP@)k?pR|jiEo!si164l>8aQSD(FDZ<*l(1Jr@abKcEfD94zsBZL)D`Klc~U0xpsTskTMqbj*T$?iX2Zu57TCp<pTBrBe*AwWfnlXmUE?EXk$p{uh4FdEH2wrct{DNC>(cf=06j`Zm*Q+@3qcLAe^;;>@WBSIn1wq&U0^RdLvirwWTb'
_HASH = 'a93e4f2f3952278834d0342bd7d48d291620f19e593b64299c3a52dfbcfdda1c'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
