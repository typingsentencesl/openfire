"""Generated at build time — do not edit."""

import base64

from openfire import _load_encrypted_module

_BLOB = '8J;++kV%O2uS&%m&M4s((yzGN=GI6jhR|u!RozDwr}&acUzMs8g_naFTI-E6<K7&L9AZ%RAY>2CAqJe0o=Aa1XY2l&^geL^+s+`@Tn@?kDEO)VD`@Vx+120@)VfIDS__WI_i=Y+FG<EQ_rd4Jy1x>zu5N!#Lxp>-_Eb<#!_Y7rfqsOhx7=*{w}<d4Bn>-rK6J@7$e9n^noxYg>tGUX+iCs&0D+Ll<$nvn>I1z`#dTuJ0N7{@7K0lJT%|cNq|0WkLR&Qrirys^o!OQh6@)kevWkX-!htGh4H8~$mhGJ+B+id9YF7W#9jfHF*=qr$0$ouXp<c6H%%Qs4lqpIjlDa>M9!gK8{%vng8<_IQv5F}b_&q@~5H(}OUb-XY;O{WGys1G&oJ@IWmgpRbzU{EE0IxDAvNYy7H}HrFt01z7h%FicM@Vj6+%p80*htK-jN2i>dADA$7r>kA_<&f7c?kyxH3pJR7K0|#5JiK+ZxxtABjtk#jxMKmsCH1}8rn`Ga3$w%?;QSeJ~V2j<0k^iUZC~!ime5Mq8(uR8B>E!Uzh*r5v5&t(--#9<w)60R`S;N!KtGeU8FRTe!R%|zwGEpX+t(wbS%7K-7dj0n9RONr<~-;?5LSWu<z=L(&+q^PEF0;34OLM!&d-vUa!we0E|~&vxIXgQ0oY!kmu0My`ie#YF?8Nd$E!>Lom>%3S8*@d(0b&q3JQG=h|LZSHGVIgTNvg+qsq>UAg{k2+Za}ECNP(x%T5ncKl3~eQe&G&%#h%YwkCQ_1G9T@te7S-RY)L`&ZhrHx>G#ZeL~ZKBI7PYJi1Ab_L@lt`@PF6#ZyeukW;N&D7;_W&_HUI^gE_b$lnIxkx?*=`S&)5i8JyY@Q5k$Xc5_(1YY$!+wzDQ90ND-d{=x)FF<Hu1m=Ol$9IdzsQ%+_p6Xcq>0lVRJM8&C8y3x)HiA_gtVA`(^~77vYXfUjkWDgxp_#=lA2|%18WXxZgH?M6b)3M0;Qdx6bm{GFAsJzUH^S1vfw4+EZl*cQMxFb!Apdxs<Ig`c<Ob6V2g^42w*8|B`XLKA>?~dIe7uY1&GM@I__gBu5r0y4>PXF)u86;hseDyIBlfW$@-5z^Hn|dzuqIFayyp7W2VBeCewn!hG3F7IJC-3WT$vwRoIFzKHyzziQ=2`21o1?LV?c0$87'
_HASH = '6db68fe46ce07c52877fa6c3d3a34ea0af2a53cc27908df214c873b021aaf81a'

_load_encrypted_module(__name__, base64.b85decode(_BLOB), bytes.fromhex(_HASH))
del _BLOB, _HASH
